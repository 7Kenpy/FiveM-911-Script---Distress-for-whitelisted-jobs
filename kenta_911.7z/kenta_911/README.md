Hi! I am KentaFPS developer of this script. 

Little info about the script: 
This is very simple, this script will allow players to call for help using /911pd/ems/mech
commands. It will notify the said whitelisted job and will last for about 2 minutes. 

Installation is very easy: 
1. Download the file and dependency (pNotify)
2. Put it inside your resources folder
3. start / ensure the script in your server.cfg

If you have questions, please join my discord server: 
https://discord.gg/TJB56dJ78n

